#include "stdio.h"
#include "math.h"
#include "stdlib.h"
#include "unistd.h"

void funcionTextSegment(){
	printf("Ejecutando funcion Text Segment... \n");
}

int main(){
	printf("Proceso en ejecución (Running - R)...\n");
	funcionTextSegment();
	while(1){
		double *resultado2 = (double *)malloc(sizeof(double));
		if(resultado2==NULL){
			perror("Error al asignar memoria al heap");
			return 1;
		}
		*resultado2 = 0;
		for (int i=0;i<1000000000;i++){
			*resultado2 += sin(i) *cos(i);
		}
		free(resultado2);

		volatile double resultado = 0;
		for(int i=0;i<10000000;i++){
			resultado += sin(i)*cos(i);
			printf("Ejecutando iteracción %lf\n", resultado);
			//sleep(1);
		}
	}
	return 0;
}
