#include "stdio.h"
#include "math.h"
#include "unistd.h"

void funcionTextSegment(){
	printf("Ejecutando funcion Text Segment... \n");
}

int main(){
	printf("Proceso en ejecución (Running - R)...\n");
	funcionTextSegment();
	while(1){
		volatile double resultado = 0;
		for(int i=0;i<10000000;i++){
			resultado += sin(i)*cos(i);
			printf("Ejecutando iteracción %lf\n", resultado);
			//sleep(1);
		}
	}
	return 0;
}
