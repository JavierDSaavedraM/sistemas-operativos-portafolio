#include "stdio.h"
#include "math.h"
#include "unistd.h"

int main(){
	printf("Proceso en ejecución (Running - R)...\n");
	while(1){
		volatile double resultado = 0;
		for(int i=0;i<10000000;i++){
			resultado += sin(i)*cos(i);
			printf("Ejecutando iteracción %lf\n", resultado);
			sleep(1);
		}
	}
	return 0;
}
