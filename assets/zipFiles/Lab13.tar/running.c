#include "stdio.h"
#include "unistd.h"

int main(){
	printf("Proceso en ejecución (Running - R)...\n");
	for(int i=0;i<5;i++){
		printf("Ejecutando iteracción %d\n", i+1);
		sleep(1);
	}
	return 0;
}
