#include "stdio.h"
#include "stdlib.h"
#include "unistd.h"
#include "signal.h"

int main(){
	pid_t pid;
	int opcion, tipo_senial;
	printf("Ingrese el PID del proceso a controlar: ");
	scanf("%d", &pid);
	while(1){
		printf("\nMenu de seniales a enviar: \n");
		printf("1.- Pausar proceso con SIGSTOP\n");
		printf("2.- Reanudar el proceso contorlado SIGCONT\n");
		printf("3.- Enviar senial SIGUSR1 con prioridad alta\n");
		printf("4.- Enviar senial SIGUSR2 con priodidad baja\n");
		printf("5.- Terminar el proceso con SIGTERM\n");
		printf("6.- Terminamos programa\n");
		printf("Seleccione la opcion favorita: ");
		scanf("%d",&opcion);

		switch(opcion){
			case 1:
				kill(pid,SIGSTOP);
				printf("Proceso %d pausado.\n", pid);
				break;
			case 2:
				kill(pid,SIGCONT);
				printf("Proceso %d reanudado.\n", pid);
				break;
			case 3:
				kill(pid,SIGUSR1);
				printf("Senial SIGUSER1 enviada al proceso %d\n", pid);
				break;
			case 4:
				kill(pid,SIGUSR2);
				printf("Senial SIGUSER2 enviada al proceso %d\n", pid);
				break;
			case 5:
				kill(pid,SIGTERM);
				printf("Senial SIGTERM enviada al proceso %d\n", pid);
				return 0;
			defaul:
				printf("Opcion invalidad, intentelo de nuevo\n");
		}
	}
}
