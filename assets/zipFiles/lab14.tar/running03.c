#include "stdio.h"
#include "math.h"
#include "unistd.h"

void funcionTextSegment(){
	printf("Ejecutando funcion Text Segment....\n");
}

int main(){
	printf("Proceso en ejecuccion (RUNNING - R) ... \n");
	funcionTextSegment();
	while(1){
		volatile double resultado = 0;
		for (int i =0; i <100000000 ; i++){
			resultado += sin(i)* cos(i);
			printf("Ejecutando iteraccion %lf\n", i+resultado);
		}
	}
	return 0;
}
