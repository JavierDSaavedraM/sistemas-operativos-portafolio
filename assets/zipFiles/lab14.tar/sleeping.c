#include "stdio.h"
#include "unistd.h"

int main(){
	printf("Proceso en estado de Sleeping(S), esperando entrada del usuario: \n");
	getchar();
	printf("Entrada recibida ... proceso ... \n");
	return 0;
}
