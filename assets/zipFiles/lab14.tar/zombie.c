#include "stdio.h"
#include "stdlib.h"
#include "unistd.h"

int main(){
	pid_t pid = fork();
	
	if (pid == 0){
		printf("Proceso hijo en estado zombie (Z)....\n");	
		exit(0);
	} else {
		printf("Proceso padre que no puede recoger al hijo...\n");
		sleep(50);
	}
	return 0;
}
