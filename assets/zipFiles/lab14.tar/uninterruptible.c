#include "stdio.h"
#include "fcntl.h"
#include "unistd.h"

int main(){
	printf("Proceso en estado D (Uninterrumptible Sleep), esperando datos de /dev/random....\n");
	int datos = open("archivo.dat", O_CREAT | O_WRONLY, 0666);
	if(datos == -1){
		perror("Error al intentar abrir el archivo");
		return 1;
}
	char buffer[4096] = {0}; // Crea un buffer de 4K bytes
	while (1){
		write(datos,buffer,sizeof(buffer));
		fsync(datos); // Forzamos la syncronizacion del cpu
	}
	close(datos);
	return 0;
}
