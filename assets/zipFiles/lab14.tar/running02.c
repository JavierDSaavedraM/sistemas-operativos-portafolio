#include "stdio.h"
#include "math.h"
#include "unistd.h"

int main(){
	printf("Proceso en ejecuccion (RUNNING - R) ... \n");
	while(1){
		volatile double resultado = 0;
		for (int i =0; i <100000000 ; i++){
			resultado += sin(i)* cos(i);
			printf("Ejecutando iteraccion %lf\n", i+resultado);
		}
	}
	return 0;
}
