#include "stdio.h"
#include "stdlib.h"
#include "math.h"
#include "unistd.h"

void funcionTextSegment(){
	printf("Ejecutando funcion Text Segment....\n");
}

int main(){
	printf("Proceso en ejecuccion (RUNNING - R) ... \n");
	funcionTextSegment();
	while(1){
		double *resultado2 = (double *)malloc(sizeof(double));
		if (resultado2 == NULL){
			perror("ERROR al asignar memoria al heap");
			return 1;
		}
		*resultado2 = 0;
		for (int i =0; i <100000000 ; i++){
			*resultado2 +=  sin(i) * cos(i);
		}



		free(resultado2);
		volatile double resultado = 0;
		for (int i =0; i <100000000 ; i++){
			resultado += sin(i)* cos(i);
			printf("Ejecutando iteraccion %lf\n", i+resultado);
		}
	}
	return 0;
}
