#include "stdio.h"
#include "signal.h"
#include "unistd.h"


int main(){
	printf("Proceso detenido, estado Stoped (T)...\n");
	raise(SIGSTOP);
	printf("PROCESO REANUDADO...\n");
	return 0;
}
