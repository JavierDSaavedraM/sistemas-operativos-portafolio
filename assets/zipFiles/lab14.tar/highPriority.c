#include "stdio.h"
#include "unistd.h"
#include "sys/resource.h"

int main(){
	printf("Proceso con prioridad alta (<)...\n");
	setpriority(PRIO_PROCESS, 0, -20);
	while(1);
	return 0;
}
